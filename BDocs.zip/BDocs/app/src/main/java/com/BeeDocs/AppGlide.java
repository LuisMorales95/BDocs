package com.BeeDocs;
import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public class AppGlide extends AppGlideModule {
}
